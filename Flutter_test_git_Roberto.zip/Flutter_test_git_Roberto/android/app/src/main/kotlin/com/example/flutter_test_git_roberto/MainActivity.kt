package com.example.flutter_test_git_roberto

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
